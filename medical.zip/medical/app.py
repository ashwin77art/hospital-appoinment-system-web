"""
app.py — MediConnect Flask Application
Connects to MongoDB via the `database` module and serves all routes.
"""

import os
from flask import Flask, render_template, request, redirect, url_for, session, flash, jsonify
import bcrypt
from datetime import datetime
from bson.objectid import ObjectId
from dotenv import load_dotenv
import re
from flask_mail import Mail, Message
from twilio.rest import Client

# ─── Load environment variables from .env ──────────────────────────────────────
load_dotenv()

# ─── Flask app setup ───────────────────────────────────────────────────────────
app = Flask(__name__)
app.secret_key = os.getenv('SECRET_KEY', 'fallback_secret_key')

# ─── Mail Configuration ────────────────────────────────────────────────────────
app.config['MAIL_SERVER'] = os.getenv('MAIL_SERVER', 'smtp.gmail.com')
app.config['MAIL_PORT'] = int(os.getenv('MAIL_PORT', 587))
app.config['MAIL_USE_TLS'] = os.getenv('MAIL_USE_TLS', 'True') == 'True'
app.config['MAIL_USERNAME'] = os.getenv('MAIL_USERNAME')
app.config['MAIL_PASSWORD'] = os.getenv('MAIL_PASSWORD')
app.config['MAIL_DEFAULT_SENDER'] = os.getenv('MAIL_DEFAULT_SENDER')

mail = Mail(app)

# ─── Database initialisation ───────────────────────────────────────────────────
from database import init_db, get_collections

try:
    init_db()
    print("[App] Database initialised successfully.")
except RuntimeError as e:
    print(f"[App] FATAL: {e}")
    print("[App] The application will start, but database operations will fail.")

def get_cols():
    """Convenience wrapper — returns collection dict for each request."""
    return get_collections()

# ─── Notification Helpers ──────────────────────────────────────────────────────
def send_email_notification(to_email, subject, body):
    if not to_email or not app.config['MAIL_USERNAME']:
        print("[NOTIFY] Email sending skipped (missing email or credentials).")
        return
    try:
        msg = Message(subject, recipients=[to_email])
        msg.body = body
        mail.send(msg)
        print(f"[NOTIFY] Email successfully sent to {to_email}")
    except Exception as e:
        print(f"[NOTIFY] Failed to send email to {to_email}: {e}")

def send_sms_notification(to_mobile, body):
    account_sid = os.getenv('TWILIO_ACCOUNT_SID')
    auth_token = os.getenv('TWILIO_AUTH_TOKEN')
    from_number = os.getenv('TWILIO_PHONE_NUMBER')

    if not to_mobile or not account_sid or not auth_token:
        print("[NOTIFY] SMS sending skipped (missing mobile or credentials).")
        return
    try:
        client = Client(account_sid, auth_token)
        message = client.messages.create(
            body=body,
            from_=from_number,
            to=to_mobile
        )
        print(f"[NOTIFY] SMS successfully sent to {to_mobile} (SID: {message.sid})")
    except Exception as e:
        print(f"[NOTIFY] Failed to send SMS to {to_mobile}: {e}")

# ──────────────────────────────────────────────────────────────────────────────
# Public Routes
# ──────────────────────────────────────────────────────────────────────────────

@app.route('/')
def index():
    return render_template('index.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        cols = get_cols()
        name     = request.form.get('name', '').strip()
        age      = request.form.get('age', '').strip()
        gender   = request.form.get('gender', '').strip()
        mobile   = request.form.get('mobile', '').strip()
        email    = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')
        address  = request.form.get('address', '').strip()

        if cols['users'].find_one({'email': email}):
            flash('Email already registered!', 'error')
            return redirect(url_for('register'))

        hashed = bcrypt.hashpw(password.encode(), bcrypt.gensalt())
        cols['users'].insert_one({
            'name':       name,
            'age':        age,
            'gender':     gender,
            'mobile':     mobile,
            'email':      email,
            'password':   hashed,
            'address':    address,
            'role':       'Patient',
            'created_at': datetime.utcnow(),
        })
        flash('Registration successful! Please log in.', 'success')
        return redirect(url_for('login'))

    return render_template('register.html')


@app.route('/register_doctor', methods=['GET', 'POST'])
def register_doctor():
    if request.method == 'POST':
        cols = get_cols()
        name       = request.form.get('name', '').strip()
        email      = request.form.get('email', '').strip().lower()
        password   = request.form.get('password', '')
        department = request.form.get('department', '').strip()
        mobile     = request.form.get('mobile', '').strip()

        if cols['users'].find_one({'email': email}):
            flash('Email already registered!', 'error')
            return redirect(url_for('register_doctor'))

        hashed = bcrypt.hashpw(password.encode(), bcrypt.gensalt())
        cols['users'].insert_one({
            'name':       name,
            'email':      email,
            'password':   hashed,
            'department': department,
            'mobile':     mobile,
            'role':       'Doctor',
            'created_at': datetime.utcnow(),
        })
        flash('Doctor registration successful! Please log in.', 'success')
        return redirect(url_for('login'))

    return render_template('register_doctor.html')


@app.route('/register_admin', methods=['GET', 'POST'])
def register_admin():
    if request.method == 'POST':
        cols = get_cols()
        name     = request.form.get('name', '').strip()
        email    = request.form.get('email', '').strip().lower()
        password = request.form.get('password', '')

        if cols['users'].find_one({'email': email}):
            flash('Email already registered!', 'error')
            return redirect(url_for('register_admin'))

        hashed = bcrypt.hashpw(password.encode(), bcrypt.gensalt())
        cols['users'].insert_one({
            'name':       name,
            'email':      email,
            'password':   hashed,
            'role':       'Admin',
            'created_at': datetime.utcnow(),
        })
        flash('Admin registration successful! Please log in.', 'success')
        return redirect(url_for('login'))

    return render_template('register_admin.html')


@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        cols     = get_cols()
        email    = request.form.get('email', '').strip() # case-insensitive search
        password = request.form.get('password', '')

        user = cols['users'].find_one({'email': {'$regex': f'^{re.escape(email)}$', '$options': 'i'}})

        if user and bcrypt.checkpw(password.encode(), user['password']):
            session['user_id'] = str(user['_id'])
            session['role']    = user['role']
            session['name']    = user['name']

            flash(f'Welcome back, {user["name"]}!', 'success')

            role_redirect = {
                'Patient': 'patient_dashboard',
                'Doctor':  'doctor_dashboard',
                'Admin':   'admin_dashboard',
            }
            return redirect(url_for(role_redirect.get(user['role'], 'index')))
        else:
            flash('Invalid email or password.', 'error')

    return render_template('login.html')


@app.route('/logout')
def logout():
    session.clear()
    flash('You have been logged out.', 'info')
    return redirect(url_for('index'))


@app.route('/forgot_password', methods=['GET', 'POST'])
def forgot_password():
    if request.method == 'POST':
        email = request.form.get('email', '').strip() # Removed .lower() to preserve input just in case, but search will be case-insensitive
        password = request.form.get('password', '')
        confirm_password = request.form.get('confirm_password', '')
        
        cols = get_cols()
        # Case-insensitive search for the email
        user = cols['users'].find_one({'email': {'$regex': f'^{re.escape(email)}$', '$options': 'i'}})
        
        if not user:
            flash('No account found with that email.', 'error')
            return redirect(url_for('forgot_password'))
            
        if password != confirm_password:
            flash('Passwords do not match.', 'error')
            return redirect(url_for('forgot_password'))
            
        hashed = bcrypt.hashpw(password.encode(), bcrypt.gensalt())
        # Update by _id to ensure we update the exact user record found, regardless of its original casing
        cols['users'].update_one({'_id': user['_id']}, {'$set': {'password': hashed}})
        
        flash('Your password has been successfully updated! You can now log in.', 'success')
        return redirect(url_for('login'))
        
    return render_template('forgot_password.html')


# ──────────────────────────────────────────────────────────────────────────────
# Patient Routes
# ──────────────────────────────────────────────────────────────────────────────

@app.route('/patient_dashboard')
def patient_dashboard():
    if session.get('role') != 'Patient':
        return redirect(url_for('login'))

    cols = get_cols()
    user = cols['users'].find_one({'_id': ObjectId(session['user_id'])})

    appointments = list(
        cols['appointments']
        .find({'patient_id': session['user_id']})
        .sort('datetime', -1)
    )

    # Enrich each appointment with doctor details from the users collection
    for appt in appointments:
        doc = cols['users'].find_one({'_id': ObjectId(appt['doctor_id'])})
        if doc:
            appt['doctor_name'] = doc['name']
            appt['department']  = doc.get('department', 'General')

    return render_template('patient_dashboard.html', user=user, appointments=appointments)


@app.route('/api/doctors')
def api_doctors():
    """Return doctors for the given department as JSON (used by the booking form)."""
    cols       = get_cols()
    department = request.args.get('department', '')
    doctors    = list(
        cols['users'].find(
            {'role': 'Doctor', 'department': department},
            {'password': 0}          # never return password hash
        )
    )
    for doc in doctors:
        doc['_id'] = str(doc['_id'])  # ObjectId → string for JSON serialisation
    return jsonify(doctors)


@app.route('/book_appointment', methods=['POST'])
def book_appointment():
    if session.get('role') != 'Patient':
        return redirect(url_for('login'))

    cols        = get_cols()
    doctor_id   = request.form.get('doctor_id', '').strip()
    dt_str      = request.form.get('datetime', '')
    description = request.form.get('description', '').strip()

    try:
        dt = datetime.strptime(dt_str, '%Y-%m-%dT%H:%M')
    except ValueError:
        flash('Invalid date/time format.', 'error')
        return redirect(url_for('patient_dashboard'))

    cols['appointments'].insert_one({
        'patient_id':   session['user_id'],
        'patient_name': session['name'],
        'doctor_id':    doctor_id,
        'datetime':     dt,
        'description':  description,
        'status':       'Pending',
        'booked_at':    datetime.utcnow(),
    })

    # Trigger notifications for booking
    patient = cols['users'].find_one({'_id': ObjectId(session['user_id'])})
    doctor = cols['users'].find_one({'_id': ObjectId(doctor_id)})
    doc_name = doctor['name'] if doctor else 'the doctor'
    appt_time = dt.strftime('%Y-%m-%d %H:%M')
    
    settings = cols['settings'].find_one({'type': 'notifications'}) or {}
    email_enabled = settings.get('email_enabled', True)
    sms_enabled = settings.get('sms_enabled', True)
    
    body = f"Hello {session['name']}, your appointment with {doc_name} on {appt_time} has been requested and is currently Pending."
    subject = "Appointment Requested"
    
    if email_enabled and patient and patient.get('email'):
        send_email_notification(patient['email'], subject, body)
    
    if sms_enabled and patient and patient.get('mobile'):
        send_sms_notification(patient['mobile'], body)

    flash('Appointment requested successfully!', 'success')
    return redirect(url_for('patient_dashboard'))


@app.route('/api/feedback', methods=['POST'])
def submit_feedback():
    if session.get('role') != 'Patient':
        return jsonify({'error': 'Unauthorized'}), 401

    cols = get_cols()
    data = request.get_json(silent=True) or {}

    appointment_id = data.get('appointment_id', '').strip()
    feedback_text  = data.get('feedback', '').strip()
    rating         = data.get('rating', 0)

    if not appointment_id or not feedback_text:
        return jsonify({'error': 'Missing appointment_id or feedback text'}), 400

    try:
        rating = int(rating)
        if not (1 <= rating <= 5):
            raise ValueError
    except (ValueError, TypeError):
        return jsonify({'error': 'Rating must be an integer between 1 and 5'}), 400

    # Prevent duplicate feedback for the same appointment
    existing = cols['feedback'].find_one({
        'appointment_id': appointment_id,
        'patient_id':     session['user_id'],
    })
    if existing:
        return jsonify({'error': 'You have already submitted feedback for this appointment'}), 409

    cols['feedback'].insert_one({
        'appointment_id': appointment_id,
        'patient_id':     session['user_id'],
        'patient_name':   session['name'],
        'feedback':       feedback_text,
        'rating':         rating,
        'submitted_at':   datetime.utcnow(),
    })

    # Mark appointment as having feedback so UI can hide the button
    cols['appointments'].update_one(
        {'_id': ObjectId(appointment_id)},
        {'$set': {'has_feedback': True}}
    )

    return jsonify({'success': True})


@app.route('/api/my_feedback')
def my_feedback():
    """Return the current patient's submitted feedback records (with appointment details)."""
    if session.get('role') != 'Patient':
        return jsonify({'error': 'Unauthorized'}), 401

    cols    = get_cols()
    records = list(
        cols['feedback']
        .find({'patient_id': session['user_id']})
        .sort('submitted_at', -1)
    )

    result = []
    for rec in records:
        appt = cols['appointments'].find_one({'_id': ObjectId(rec['appointment_id'])})
        doc_name = 'N/A'
        department = 'N/A'
        appt_dt = ''
        if appt:
            doc = cols['users'].find_one({'_id': ObjectId(appt['doctor_id'])})
            if doc:
                doc_name   = doc['name']
                department = doc.get('department', 'General')
            appt_dt = appt['datetime'].strftime('%Y-%m-%d %H:%M')

        result.append({
            'feedback':     rec['feedback'],
            'rating':       rec['rating'],
            'submitted_at': rec['submitted_at'].strftime('%Y-%m-%d'),
            'doctor_name':  doc_name,
            'department':   department,
            'appt_datetime': appt_dt,
        })

    return jsonify(result)


# ──────────────────────────────────────────────────────────────────────────────
# Doctor Routes
# ──────────────────────────────────────────────────────────────────────────────

@app.route('/doctor_dashboard')
def doctor_dashboard():
    if session.get('role') != 'Doctor':
        return redirect(url_for('login'))

    cols = get_cols()
    user = cols['users'].find_one({'_id': ObjectId(session['user_id'])})

    now            = datetime.now()
    start_of_today = datetime(now.year, now.month, now.day)
    end_of_today   = datetime(now.year, now.month, now.day, 23, 59, 59)

    all_appointments = list(
        cols['appointments']
        .find({'doctor_id': session['user_id']})
        .sort('datetime', 1)
    )

    today_appointments   = []
    future_appointments  = []
    visited_appointments = []

    for appt in all_appointments:
        status = appt.get('status')
        if status in ['Visited', 'Completed']:
            # Fetch patient demographics/details if available
            patient = None
            if appt.get('patient_id'):
                try:
                    patient = cols['users'].find_one({'_id': ObjectId(appt['patient_id'])})
                except Exception:
                    pass
            appt['patient_details'] = patient
            visited_appointments.append(appt)
            
        appt_dt = appt['datetime']
        if start_of_today <= appt_dt <= end_of_today and status not in ['Visited', 'Completed', 'Cancelled']:
            today_appointments.append(appt)
        elif appt_dt > end_of_today and status not in ['Visited', 'Completed', 'Cancelled']:
            future_appointments.append(appt)

    # Sort visited appointments newest first
    visited_appointments.sort(key=lambda x: x.get('visited_at') or x.get('datetime'), reverse=True)

    return render_template(
        'doctor_dashboard.html',
        user=user,
        today_appointments=today_appointments,
        future_appointments=future_appointments,
        visited_appointments=visited_appointments,
    )


@app.route('/doctor_mark_visited/<appt_id>', methods=['POST'])
def doctor_mark_visited(appt_id):
    if session.get('role') != 'Doctor':
        return redirect(url_for('login'))

    doctor_notes = request.form.get('doctor_notes', '').strip()

    cols = get_cols()
    cols['appointments'].update_one(
        {'_id': ObjectId(appt_id), 'doctor_id': session['user_id']},
        {'$set': {
            'status': 'Visited',
            'visited_at': datetime.utcnow(),
            'doctor_notes': doctor_notes
        }}
    )
    flash('Patient marked as visited and notes saved.', 'success')
    return redirect(url_for('doctor_dashboard'))



# ──────────────────────────────────────────────────────────────────────────────
# Admin Routes
# ──────────────────────────────────────────────────────────────────────────────

@app.route('/admin_dashboard')
def admin_dashboard():
    if session.get('role') != 'Admin':
        return redirect(url_for('login'))

    cols = get_cols()

    pending_appointments = list(
        cols['appointments'].find({'status': 'Pending'}).sort('datetime', 1)
    )
    visited_appointments = list(
        cols['appointments'].find({'status': 'Visited'}).sort('datetime', 1)
    )

    # Enrich with doctor names
    for appt in pending_appointments + visited_appointments:
        doc = cols['users'].find_one({'_id': ObjectId(appt['doctor_id'])})
        if doc:
            appt['doctor_name'] = doc['name']

    doctors  = list(cols['users'].find({'role': 'Doctor'}, {'password': 0}))
    settings = cols['settings'].find_one({'type': 'notifications'}) or {
        'email_enabled': True,
        'sms_enabled':   True,
    }

    return render_template(
        'admin_dashboard.html',
        pending_appointments=pending_appointments,
        visited_appointments=visited_appointments,
        doctors=doctors,
        settings=settings,
    )


@app.route('/admin_update_appointment/<appt_id>/<status>', methods=['POST'])
def admin_update_appointment(appt_id, status):
    if session.get('role') != 'Admin':
        return redirect(url_for('login'))

    cols           = get_cols()
    allowed_status = {'Confirmed', 'Completed', 'Cancelled'}

    if status not in allowed_status:
        flash('Invalid status value.', 'error')
        return redirect(url_for('admin_dashboard'))

    cols['appointments'].update_one(
        {'_id': ObjectId(appt_id)},
        {'$set': {'status': status, 'updated_at': datetime.utcnow()}}
    )
    flash(f'Appointment status updated to {status}.', 'success')

    # Simulate notifications when appointment is confirmed
    if status == 'Confirmed':
        appt = cols['appointments'].find_one({'_id': ObjectId(appt_id)})
        if appt:
            patient  = cols['users'].find_one({'_id': ObjectId(appt['patient_id'])})
            settings = cols['settings'].find_one({'type': 'notifications'}) or {}

            if patient:
                notified_via = []
                appt_time    = appt['datetime'].strftime('%Y-%m-%d %H:%M')
                
                doctor = cols['users'].find_one({'_id': ObjectId(appt['doctor_id'])})
                doc_name = doctor['name'] if doctor else "Unknown"
                description = appt.get('description', 'N/A')

                msg_body = (
                    f"Hello {patient['name']},\n\n"
                    f"Your appointment has been Confirmed!\n\n"
                    f"Details:\n"
                    f"- Date & Time: {appt_time}\n"
                    f"- Doctor: Dr. {doc_name}\n"
                    f"- Reason: {description}\n\n"
                    f"Thank you for using MediConnect."
                )

                if settings.get('email_enabled', True) and patient.get('email'):
                    subject = "Appointment Confirmed"
                    send_email_notification(patient['email'], subject, msg_body)
                    notified_via.append('Email')

                if settings.get('sms_enabled', True) and patient.get('mobile'):
                    send_sms_notification(patient['mobile'], msg_body)
                    notified_via.append('SMS')

                if notified_via:
                    flash(
                        f"Notification sent to patient via {' and '.join(notified_via)}.",
                        'info'
                    )

    return redirect(url_for('admin_dashboard'))


@app.route('/admin_add_doctor', methods=['POST'])
def admin_add_doctor():
    if session.get('role') != 'Admin':
        return redirect(url_for('login'))

    cols       = get_cols()
    name       = request.form.get('name', '').strip()
    email      = request.form.get('email', '').strip().lower()
    password   = request.form.get('password', '')
    department = request.form.get('department', '').strip()

    if cols['users'].find_one({'email': email}):
        flash('Email already in use.', 'error')
        return redirect(url_for('admin_dashboard'))

    hashed = bcrypt.hashpw(password.encode(), bcrypt.gensalt())
    cols['users'].insert_one({
        'name':       name,
        'email':      email,
        'password':   hashed,
        'department': department,
        'role':       'Doctor',
        'created_at': datetime.utcnow(),
    })
    flash('Doctor added successfully.', 'success')
    return redirect(url_for('admin_dashboard'))


@app.route('/admin_remove_doctor/<doctor_id>', methods=['POST'])
def admin_remove_doctor(doctor_id):
    if session.get('role') != 'Admin':
        return redirect(url_for('login'))

    cols = get_cols()
    
    result = cols['users'].delete_one({'_id': ObjectId(doctor_id), 'role': 'Doctor'})
    
    if result.deleted_count > 0:
        flash('Doctor removed successfully.', 'success')
    else:
        flash('Doctor not found or could not be removed.', 'error')
        
    return redirect(url_for('admin_dashboard'))


# ──────────────────────────────────────────────────────────────────────────────
# Entry point
# ──────────────────────────────────────────────────────────────────────────────
if __name__ == '__main__':
    app.run(
        debug=os.getenv('FLASK_DEBUG', 'True') == 'True',
        host=os.getenv('FLASK_HOST', '0.0.0.0'),
        port=int(os.getenv('FLASK_PORT', 5000)),
    )
