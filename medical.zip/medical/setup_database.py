from pymongo import MongoClient
import bcrypt
from datetime import datetime, timedelta

def setup_database():
    print("Connecting to MongoDB...")
    try:
        client = MongoClient('mongodb://localhost:27017/')
        # Access the database (it will be created if it doesn't exist)
        db = client['medical_db']
        
        users_collection = db['users']
        appointments_collection = db['appointments']
        settings_collection = db['settings']

        print("Database 'medical_db' created/accessed successfully.")

        # 1. Create an Admin user
        if not users_collection.find_one({'email': 'admin@mediconnect.com'}):
            print("Creating default Admin user...")
            hashed_password = bcrypt.hashpw('admin123'.encode('utf-8'), bcrypt.gensalt())
            users_collection.insert_one({
                'name': 'System Admin',
                'email': 'admin@mediconnect.com',
                'password': hashed_password,
                'role': 'Admin'
            })
        else:
            print("Admin user already exists.")

        # 2. Create a Sample Doctor
        if not users_collection.find_one({'email': 'doctor@mediconnect.com'}):
            print("Creating sample Doctor user...")
            hashed_password = bcrypt.hashpw('doctor123'.encode('utf-8'), bcrypt.gensalt())
            doctor_id = users_collection.insert_one({
                'name': 'Dr. Smith',
                'email': 'doctor@mediconnect.com',
                'password': hashed_password,
                'department': 'Cardiology',
                'mobile': '1234567890',
                'role': 'Doctor'
            }).inserted_id
        else:
            print("Sample Doctor user already exists.")
            doctor_id = users_collection.find_one({'email': 'doctor@mediconnect.com'})['_id']

        # 3. Create a Sample Patient
        if not users_collection.find_one({'email': 'patient@mediconnect.com'}):
            print("Creating sample Patient user...")
            hashed_password = bcrypt.hashpw('patient123'.encode('utf-8'), bcrypt.gensalt())
            patient_id = users_collection.insert_one({
                'name': 'John Doe',
                'age': '30',
                'gender': 'Male',
                'mobile': '0987654321',
                'email': 'patient@mediconnect.com',
                'password': hashed_password,
                'address': '123 Main St, City',
                'role': 'Patient'
            }).inserted_id
        else:
            print("Sample Patient user already exists.")
            patient_id = users_collection.find_one({'email': 'patient@mediconnect.com'})['_id']

        # 4. Create a Sample Appointment
        if not appointments_collection.find_one({'patient_id': str(patient_id)}):
            print("Creating sample Appointment...")
            appointments_collection.insert_one({
                'patient_id': str(patient_id),
                'patient_name': 'John Doe',
                'doctor_id': str(doctor_id),
                'datetime': datetime.now() + timedelta(days=1),
                'description': 'Routine checkup for heart',
                'status': 'Pending'
            })
        else:
            print("Sample Appointment already exists.")

        # 5. Default Settings
        if not settings_collection.find_one({'type': 'notifications'}):
            print("Creating default Settings...")
            settings_collection.insert_one({
                'type': 'notifications',
                'email_enabled': True,
                'sms_enabled': True
            })
            
        print("\nDatabase initialization complete!")
        print("You can now log in with:")
        print("Admin: admin@mediconnect.com / admin123")
        print("Doctor: doctor@mediconnect.com / doctor123")
        print("Patient: patient@mediconnect.com / patient123")

    except Exception as e:
        print("An error occurred while setting up the database:", e)
        print("Please ensure MongoDB is installed and running on your system (localhost:27017).")

if __name__ == '__main__':
    setup_database()
