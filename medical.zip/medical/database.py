"""
database.py — Central MongoDB connection and collection helpers for MediConnect.

All database interactions go through this module. Import `db_collections` to
access any collection, or call the helper functions directly.
"""

import os
from pymongo import MongoClient, ASCENDING, DESCENDING
from pymongo.errors import ConnectionFailure, ServerSelectionTimeoutError
import bcrypt
from datetime import datetime
from dotenv import load_dotenv

# Load environment variables from .env file
load_dotenv()

# ─────────────────────────────────────────────
# Configuration
# ─────────────────────────────────────────────
MONGO_URI    = os.getenv('MONGO_URI',    'mongodb://localhost:27017/')
MONGO_DB     = os.getenv('MONGO_DB_NAME', 'medical_db')

# ─────────────────────────────────────────────
# Connection
# ─────────────────────────────────────────────
def get_db():
    """
    Return a (client, db) tuple. Raises RuntimeError if MongoDB is unreachable.
    Uses a module-level singleton so the connection is reused across requests.
    """
    if not hasattr(get_db, '_client') or get_db._client is None:
        try:
            client = MongoClient(MONGO_URI, serverSelectionTimeoutMS=3000)
            # Verify the connection is alive
            client.admin.command('ping')
            get_db._client = client
            print(f"[DB] Connected to MongoDB at {MONGO_URI}, database: '{MONGO_DB}'")
        except (ConnectionFailure, ServerSelectionTimeoutError) as e:
            raise RuntimeError(
                f"[DB] Could not connect to MongoDB at {MONGO_URI}.\n"
                f"Make sure MongoDB is running. Error: {e}"
            )
    return get_db._client, get_db._client[MONGO_DB]

# Reset singleton (useful in tests)
def close_db():
    if hasattr(get_db, '_client') and get_db._client:
        get_db._client.close()
        get_db._client = None
        print("[DB] MongoDB connection closed.")

# ─────────────────────────────────────────────
# Collections — convenient named references
# ─────────────────────────────────────────────
def get_collections():
    """Return a dict of all named collections."""
    _, db = get_db()
    return {
        'users':        db['users'],
        'appointments': db['appointments'],
        'feedback':     db['feedback'],
        'settings':     db['settings'],
    }

# ─────────────────────────────────────────────
# Index Setup — call once at startup
# ─────────────────────────────────────────────
def ensure_indexes():
    """
    Create indexes to speed up common queries.
    Safe to call multiple times (MongoDB ignores existing indexes).
    """
    _, db = get_db()

    # users: look up by email (login, duplicate-check) and by role (list doctors)
    db['users'].create_index([('email', ASCENDING)], unique=True, name='idx_users_email')
    db['users'].create_index([('role',  ASCENDING)],             name='idx_users_role')

    # appointments: look up by patient, doctor, and status (dashboard queries)
    db['appointments'].create_index([('patient_id', ASCENDING)], name='idx_appt_patient')
    db['appointments'].create_index([('doctor_id',  ASCENDING)], name='idx_appt_doctor')
    db['appointments'].create_index([('status',     ASCENDING)], name='idx_appt_status')
    db['appointments'].create_index([('datetime',   DESCENDING)],name='idx_appt_datetime')

    # feedback: look up by appointment
    db['feedback'].create_index([('appointment_id', ASCENDING)], name='idx_feedback_appt')

    print("[DB] Indexes ensured.")

# ─────────────────────────────────────────────
# Seed Data — call once at startup
# ─────────────────────────────────────────────
def seed_default_data():
    """
    Insert default Admin user and notification settings if they don't exist.
    This ensures the app is usable right after a fresh database setup.
    """
    cols = get_collections()

    # Default Admin
    if not cols['users'].find_one({'email': 'admin@mediconnect.com'}):
        hashed = bcrypt.hashpw('admin123'.encode(), bcrypt.gensalt())
        cols['users'].insert_one({
            'name':     'System Admin',
            'email':    'admin@mediconnect.com',
            'password': hashed,
            'role':     'Admin',
            'created_at': datetime.utcnow(),
        })
        print("[DB] Default Admin user created.")

    # Default Notification Settings
    if not cols['settings'].find_one({'type': 'notifications'}):
        cols['settings'].insert_one({
            'type':          'notifications',
            'email_enabled': True,
            'sms_enabled':   True,
            'created_at':    datetime.utcnow(),
        })
        print("[DB] Default notification settings created.")

# ─────────────────────────────────────────────
# Helper: initialise everything at app startup
# ─────────────────────────────────────────────
def init_db():
    """
    Master init function called from app.py.
    Connects, ensures indexes, and seeds required data.
    """
    get_db()          # connect & verify
    ensure_indexes()  # create indexes
    seed_default_data()  # seed defaults
