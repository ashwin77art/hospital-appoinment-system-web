/* ═══════════════════════════════════════════════════════════
   MediConnect — Main JavaScript
   Handles: flash auto-hide, form validation, AJAX helpers,
            loading states, modal, and active-nav tracking.
   ═══════════════════════════════════════════════════════════ */

document.addEventListener('DOMContentLoaded', () => {

  /* ── 1. Flash messages: auto-dismiss after 4 s ────────────── */
  document.querySelectorAll('.alert').forEach(alert => {
    setTimeout(() => {
      alert.style.transition = 'opacity 0.4s ease';
      alert.style.opacity = '0';
      setTimeout(() => alert.remove(), 400);
    }, 4000);
  });

  /* ── 2. Active navbar link highlighting ───────────────────── */
  const currentPath = window.location.pathname;
  document.querySelectorAll('.nav-links a').forEach(link => {
    if (link.getAttribute('href') === currentPath) {
      link.classList.add('active-nav');
    }
  });

  /* ── 3. Client-side form validation helpers ───────────────── */
  document.querySelectorAll('form[data-validate]').forEach(form => {
    form.addEventListener('submit', e => {
      let valid = true;
      form.querySelectorAll('[required]').forEach(field => {
        if (!field.value.trim()) {
          markInvalid(field, 'This field is required.');
          valid = false;
        } else {
          markValid(field);
        }
      });

      // Password length check
      const pwd = form.querySelector('input[name="password"]');
      if (pwd && pwd.value.length < 6) {
        markInvalid(pwd, 'Password must be at least 6 characters.');
        valid = false;
      }

      if (!valid) e.preventDefault();
    });

    // Live clear on input
    form.querySelectorAll('.form-control').forEach(field => {
      field.addEventListener('input', () => markValid(field));
    });
  });

  /* ── 4. Button loading state (prevent double-submit) ─────── */
  document.querySelectorAll('form').forEach(form => {
    form.addEventListener('submit', () => {
      const btn = form.querySelector('button[type="submit"]');
      if (btn) {
        btn.disabled = true;
        btn.dataset.original = btn.textContent;
        btn.innerHTML = '<span class="spinner"></span> Please wait…';
        // Re-enable after 8 s (network timeout fallback)
        setTimeout(() => {
          btn.disabled = false;
          btn.textContent = btn.dataset.original;
        }, 8000);
      }
    });
  });

});

/* ── Helper: mark field invalid ───────────────────────────── */
function markInvalid(field, msg) {
  field.classList.add('is-invalid');
  field.classList.remove('is-valid');
  let err = field.parentElement.querySelector('.field-error');
  if (!err) {
    err = document.createElement('span');
    err.className = 'field-error';
    field.parentElement.appendChild(err);
  }
  err.textContent = msg;
}

/* ── Helper: mark field valid ─────────────────────────────── */
function markValid(field) {
  field.classList.remove('is-invalid');
  field.classList.add('is-valid');
  const err = field.parentElement.querySelector('.field-error');
  if (err) err.remove();
}

/* ══════════════════════════════════════════════════════════════
   Patient Dashboard — Doctor fetch + Feedback modal
   ══════════════════════════════════════════════════════════════ */

/**
 * Called when the department dropdown changes.
 * Fetches doctors from /api/doctors and populates the doctor select.
 */
function fetchDoctors() {
  const dept      = document.getElementById('department').value;
  const docSelect = document.getElementById('doctor');
  const loader    = document.getElementById('doctor-loader');

  if (!dept) {
    docSelect.innerHTML = '<option value="">First select a department…</option>';
    docSelect.disabled  = true;
    return;
  }

  // Show loading state
  docSelect.disabled  = true;
  docSelect.innerHTML = '<option value="">Loading doctors…</option>';
  if (loader) loader.style.display = 'inline';

  fetch('/api/doctors?department=' + encodeURIComponent(dept))
    .then(res => {
      if (!res.ok) throw new Error('Network error');
      return res.json();
    })
    .then(doctors => {
      if (loader) loader.style.display = 'none';
      if (doctors.length === 0) {
        docSelect.innerHTML = '<option value="">No doctors available in this department.</option>';
        return;
      }
      docSelect.innerHTML = '<option value="">Select a doctor…</option>';
      doctors.forEach(doc => {
        const opt   = document.createElement('option');
        opt.value   = doc._id;
        opt.textContent = 'Dr. ' + doc.name;
        docSelect.appendChild(opt);
      });
      docSelect.disabled = false;
    })
    .catch(() => {
      if (loader) loader.style.display = 'none';
      docSelect.innerHTML = '<option value="">Error loading doctors. Try again.</option>';
    });
}


/* ══════════════════════════════════════════════════════════════
   Tab switching — used in all three dashboards
   ══════════════════════════════════════════════════════════════ */

/**
 * showTab(tabName) — hide all .tab-content panels, show the requested one,
 * and highlight the matching sidebar link.
 * Also persists the active tab in sessionStorage so refreshes keep the tab.
 */
function showTab(tabName, linkEl) {
  document.querySelectorAll('.tab-content').forEach(el => el.style.display = 'none');
  document.querySelectorAll('.sidebar-menu a').forEach(el => el.classList.remove('active'));

  const panel = document.getElementById('tab-' + tabName);
  if (panel) panel.style.display = 'block';

  // Highlight correct sidebar link
  const navLink = document.getElementById('nav-' + tabName) || linkEl;
  if (navLink) navLink.classList.add('active');

  sessionStorage.setItem('activeTab', tabName);
}

/* Restore last active tab on page load */
(function restoreTab() {
  const saved = sessionStorage.getItem('activeTab');
  if (saved) {
    const panel = document.getElementById('tab-' + saved);
    if (panel) {
      showTab(saved);
      return;
    }
  }
  // Default: show first .tab-content
  const first = document.querySelector('.tab-content');
  if (first) first.style.display = 'block';
  const firstNav = document.querySelector('.sidebar-menu a');
  if (firstNav) firstNav.classList.add('active');
})();

/* ══════════════════════════════════════════════════════════════
   Toast notification (lightweight, no library needed)
   ══════════════════════════════════════════════════════════════ */
function showToast(message, type = 'info') {
  let container = document.getElementById('toast-container');
  if (!container) {
    container = document.createElement('div');
    container.id = 'toast-container';
    document.body.appendChild(container);
  }

  const toast = document.createElement('div');
  toast.className = `toast toast-${type}`;
  toast.textContent = message;
  container.appendChild(toast);

  // Animate in
  requestAnimationFrame(() => toast.classList.add('toast-show'));

  setTimeout(() => {
    toast.classList.remove('toast-show');
    setTimeout(() => toast.remove(), 400);
  }, 4000);
}
